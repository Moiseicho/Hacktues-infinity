﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class planet : MonoBehaviour
{
    public int mass, diameter, densety, DistanceFromSun, NumberOfMoons;
    public float gravity, LengthOfDay, SurfacePressure;
    public bool RingSystem, GMF;
    public string Name;
}
